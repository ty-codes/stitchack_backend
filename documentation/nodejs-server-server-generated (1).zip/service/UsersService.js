'use strict';


/**
 * add customer
 *
 * body List Details of customer. Required.
 * userId String pass user Id as parameter
 * returns List
 **/
exports.addCustomer = function(body,userId) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = [ {
  "message" : "Customer list has been updated"
}, {
  "message" : "Customer list has been updated"
} ];
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * gets customers
 *
 * userId String pass user Id as parameter
 * returns List
 **/
exports.getCustomers = function(userId) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = [ {
  "firstname" : "Paul",
  "address" : "4, victoria estate, ogba, lagos",
  "phoneNumber" : "1234567890",
  "gender" : "male",
  "email" : "pauljohnson@gmail.com",
  "cid" : "046b6c7f-0b8a-43b9-b35d-6489e6daee91",
  "lastname" : "Johnson"
}, {
  "firstname" : "Paul",
  "address" : "4, victoria estate, ogba, lagos",
  "phoneNumber" : "1234567890",
  "gender" : "male",
  "email" : "pauljohnson@gmail.com",
  "cid" : "046b6c7f-0b8a-43b9-b35d-6489e6daee91",
  "lastname" : "Johnson"
} ];
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * gets user details
 *
 * userId String pass user Id as parameter
 * returns List
 **/
exports.getUserDetails = function(userId) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = [ {
  "firstname" : "Paul",
  "isGoogle" : false,
  "dateCreated" : "2016-08-29T09:12:33.001Z",
  "phoneNumber" : "1234567890",
  "isFb" : false,
  "id" : "046b6c7f-0b8a-43b9-b35d-6489e6daee91",
  "_id" : "046b6c7f-0b8a-43b9-b35d-6489e6daee91",
  "email" : "pauljohnson@gmail.com",
  "lastname" : "Johnson",
  "status" : "pending"
}, {
  "firstname" : "Paul",
  "isGoogle" : false,
  "dateCreated" : "2016-08-29T09:12:33.001Z",
  "phoneNumber" : "1234567890",
  "isFb" : false,
  "id" : "046b6c7f-0b8a-43b9-b35d-6489e6daee91",
  "_id" : "046b6c7f-0b8a-43b9-b35d-6489e6daee91",
  "email" : "pauljohnson@gmail.com",
  "lastname" : "Johnson",
  "status" : "pending"
} ];
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

