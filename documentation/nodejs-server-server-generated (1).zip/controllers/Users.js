'use strict';

var utils = require('../utils/writer.js');
var Users = require('../service/UsersService');

module.exports.addCustomer = function addCustomer (req, res, next, body, userId) {
  Users.addCustomer(body, userId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.getCustomers = function getCustomers (req, res, next, userId) {
  Users.getCustomers(userId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.getUserDetails = function getUserDetails (req, res, next, userId) {
  Users.getUserDetails(userId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
