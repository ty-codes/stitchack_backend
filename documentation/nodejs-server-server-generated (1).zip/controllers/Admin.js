'use strict';

var utils = require('../utils/writer.js');
var Admin = require('../service/AdminService');

module.exports.deleteUser = function deleteUser (req, res, next, body, userId) {
  Admin.deleteUser(body, userId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
