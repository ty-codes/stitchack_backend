'use strict';


/**
 * gets outstanding income
 *
 * userId String pass user Id as parameter
 * returns List
 **/
exports.getOutstandingIncome = function(userId) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = [ {
  "total" : 30000
}, {
  "total" : 30000
} ];
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * gets total income
 *
 * userId String pass user Id as parameter
 * returns List
 **/
exports.getTotalIncome = function(userId) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = [ {
  "total" : 30000
}, {
  "total" : 30000
} ];
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

