'use strict';

var utils = require('../utils/writer.js');
var Catalogue = require('../service/CatalogueService');

module.exports.addCatalogueUnit = function addCatalogueUnit (req, res, next, body, userId) {
  Catalogue.addCatalogueUnit(body, userId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.getCatalogue = function getCatalogue (req, res, next, userId) {
  Catalogue.getCatalogue(userId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.removeCatalogueUnit = function removeCatalogueUnit (req, res, next, body, userId) {
  Catalogue.removeCatalogueUnit(body, userId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
