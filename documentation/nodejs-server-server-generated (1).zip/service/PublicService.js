'use strict';


/**
 * login user
 *
 * body List user body.
 * returns List
 **/
exports.loginUser = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = [ {
  "user" : {
    "id" : "1234re23ed",
    "_id" : "d290f1ee6c544b01",
    "firstname" : "paul",
    "lastname" : "johnson",
    "email" : "pauljohnson@gmail.com",
    "isGoogle" : false,
    "isFb" : false,
    "status" : "pending",
    "dateCreated" : "2016-08-29T09:12:33.001Z",
    "phoneNumber" : "00000000000"
  },
  "token" : "token"
}, {
  "user" : {
    "id" : "1234re23ed",
    "_id" : "d290f1ee6c544b01",
    "firstname" : "paul",
    "lastname" : "johnson",
    "email" : "pauljohnson@gmail.com",
    "isGoogle" : false,
    "isFb" : false,
    "status" : "pending",
    "dateCreated" : "2016-08-29T09:12:33.001Z",
    "phoneNumber" : "00000000000"
  },
  "token" : "token"
} ];
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * register user
 *
 * body List user body.
 * returns List
 **/
exports.registerUser = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = [ {
  "acknowledged" : true,
  "insertedId" : "046b6c7f-0b8a-43b9-b35d-6489e6daee91"
}, {
  "acknowledged" : true,
  "insertedId" : "046b6c7f-0b8a-43b9-b35d-6489e6daee91"
} ];
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

