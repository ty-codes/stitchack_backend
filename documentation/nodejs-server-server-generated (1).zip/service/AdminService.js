'use strict';


/**
 * delete user
 *
 * body Users_userId_body Order id, newStatus
 * userId String pass user Id as parameter
 * returns List
 **/
exports.deleteUser = function(body,userId) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = [ {
  "upsertedCount" : 0,
  "upsertedId" : "upsertedId",
  "acknowledged" : true,
  "modifiedCount" : 1,
  "matchedCount" : 1
}, {
  "upsertedCount" : 0,
  "upsertedId" : "upsertedId",
  "acknowledged" : true,
  "modifiedCount" : 1,
  "matchedCount" : 1
} ];
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

