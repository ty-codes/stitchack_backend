'use strict';

var utils = require('../utils/writer.js');
var Measurements = require('../service/MeasurementsService');

module.exports.addMeasurements = function addMeasurements (req, res, next, body, userId) {
  Measurements.addMeasurements(body, userId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.editMeasurements = function editMeasurements (req, res, next, body, userId) {
  Measurements.editMeasurements(body, userId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.getMeasurements = function getMeasurements (req, res, next, userId) {
  Measurements.getMeasurements(userId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
