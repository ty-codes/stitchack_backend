'use strict';

var utils = require('../utils/writer.js');
var Income = require('../service/IncomeService');

module.exports.getOutstandingIncome = function getOutstandingIncome (req, res, next, userId) {
  Income.getOutstandingIncome(userId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.getTotalIncome = function getTotalIncome (req, res, next, userId) {
  Income.getTotalIncome(userId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
