'use strict';


/**
 * add style to catalogue
 *
 * body List Catalogue fields
 * userId String pass user Id as parameter
 * returns List
 **/
exports.addCatalogueUnit = function(body,userId) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = [ {
  "message" : "Customer list has been updated"
}, {
  "message" : "Customer list has been updated"
} ];
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * gets catalogue
 *
 * userId String pass user Id as parameter
 * returns List
 **/
exports.getCatalogue = function(userId) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = [ {
  "fabric" : "crepe",
  "name" : "crepe skirt",
  "style" : "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBwgHBgkIBwgKCgkLDRYPDQwMDRsUFRAWIB0iIiAdHx8kKDQsJCYxJx8fLT0tMTU3Ojo6Iys/RD84QzQ5OjcBCgoKDQwNGg8PGjclHyU3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3N//AABEIAIgAbQMBIgACEQEDEQH/xAAcAAADAAIDAQAAAAAAAAAAAAAAAQIDBwQFBgj/",
  "id" : "046b6c7f-0b8a-43b9-b35d-6489e6daee91"
}, {
  "fabric" : "crepe",
  "name" : "crepe skirt",
  "style" : "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBwgHBgkIBwgKCgkLDRYPDQwMDRsUFRAWIB0iIiAdHx8kKDQsJCYxJx8fLT0tMTU3Ojo6Iys/RD84QzQ5OjcBCgoKDQwNGg8PGjclHyU3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3N//AABEIAIgAbQMBIgACEQEDEQH/xAAcAAADAAIDAQAAAAAAAAAAAAAAAQIDBwQFBgj/",
  "id" : "046b6c7f-0b8a-43b9-b35d-6489e6daee91"
} ];
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * delete style from catalogue
 *
 * body Catalogue_userId_body Catalogue id
 * userId String pass user Id as parameter
 * returns List
 **/
exports.removeCatalogueUnit = function(body,userId) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = [ {
  "upsertedCount" : 0,
  "upsertedId" : "upsertedId",
  "acknowledged" : true,
  "modifiedCount" : 1,
  "matchedCount" : 1
}, {
  "upsertedCount" : 0,
  "upsertedId" : "upsertedId",
  "acknowledged" : true,
  "modifiedCount" : 1,
  "matchedCount" : 1
} ];
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

