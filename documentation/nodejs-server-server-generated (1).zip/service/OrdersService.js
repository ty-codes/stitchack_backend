'use strict';


/**
 * add order to orders
 *
 * body List Order fields
 * userId String pass user Id as parameter
 * returns List
 **/
exports.addOrder = function(body,userId) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = [ {
  "upsertedCount" : 0,
  "upsertedId" : "upsertedId",
  "acknowledged" : true,
  "modifiedCount" : 1,
  "matchedCount" : 1
}, {
  "upsertedCount" : 0,
  "upsertedId" : "upsertedId",
  "acknowledged" : true,
  "modifiedCount" : 1,
  "matchedCount" : 1
} ];
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * gets orders
 *
 * userId String pass user Id as parameter
 * returns List
 **/
exports.getOrders = function(userId) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = [ {
  "dateDue" : "2016-08-29T09:12:33.001Z",
  "dateCreated" : "2016-08-29T09:12:33.001Z",
  "price" : "1000",
  "style" : "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBwgHBgkIBwgKCgkLDRYPDQwMDRsUFRAWIB0iIiAdHx8kKDQsJCYxJx8fLT0tMTU3Ojo6Iys/RD84QzQ5OjcBCgoKDQwNGg8PGjclHyU3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3N//AABEIAIgAbQMBIgACEQEDEQH/xAAcAAADAAIDAQAAAAAAAAAAAAAAAQIDBwQFBgj/",
  "id" : "046b6c7f-0b8a-43b9-b35d-6489e6daee91",
  "cid" : "046b6c7f-0b8a-43b9-b35d-6489e6daee91",
  "status" : "not started"
}, {
  "dateDue" : "2016-08-29T09:12:33.001Z",
  "dateCreated" : "2016-08-29T09:12:33.001Z",
  "price" : "1000",
  "style" : "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBwgHBgkIBwgKCgkLDRYPDQwMDRsUFRAWIB0iIiAdHx8kKDQsJCYxJx8fLT0tMTU3Ojo6Iys/RD84QzQ5OjcBCgoKDQwNGg8PGjclHyU3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3N//AABEIAIgAbQMBIgACEQEDEQH/xAAcAAADAAIDAQAAAAAAAAAAAAAAAQIDBwQFBgj/",
  "id" : "046b6c7f-0b8a-43b9-b35d-6489e6daee91",
  "cid" : "046b6c7f-0b8a-43b9-b35d-6489e6daee91",
  "status" : "not started"
} ];
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * update status of order
 *
 * body Status_userId_body Order id, newStatus
 * userId String pass user Id as parameter
 * returns List
 **/
exports.updateStatus = function(body,userId) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = [ {
  "upsertedCount" : 0,
  "upsertedId" : "upsertedId",
  "acknowledged" : true,
  "modifiedCount" : 1,
  "matchedCount" : 1
}, {
  "upsertedCount" : 0,
  "upsertedId" : "upsertedId",
  "acknowledged" : true,
  "modifiedCount" : 1,
  "matchedCount" : 1
} ];
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

