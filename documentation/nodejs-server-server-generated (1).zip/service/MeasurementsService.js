'use strict';


/**
 * add customer measurements
 *
 * body List customer measurements in cm. Required.
 * userId String pass user Id as parameter
 * returns List
 **/
exports.addMeasurements = function(body,userId) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = [ {
  "acknowledged" : true,
  "insertedId" : "046b6c7f-0b8a-43b9-b35d-6489e6daee91"
}, {
  "acknowledged" : true,
  "insertedId" : "046b6c7f-0b8a-43b9-b35d-6489e6daee91"
} ];
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * edit customer measurements
 *
 * body UserId_measurements_body customer measurements in cm
 * userId String pass user Id as parameter
 * returns inline_response_200
 **/
exports.editMeasurements = function(body,userId) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "message" : "Updated successfully"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * gets customer measurements
 *
 * userId String pass user Id as parameter
 * returns List
 **/
exports.getMeasurements = function(userId) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = [ {
  "bust" : "Johnson",
  "waist" : "Johnson",
  "hip" : "Johnson"
}, {
  "bust" : "Johnson",
  "waist" : "Johnson",
  "hip" : "Johnson"
} ];
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

